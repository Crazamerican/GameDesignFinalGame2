Controls:
Pepsi Player:
Move up -> W
Move Right -> D
Move Down -> S
Move Left -> A
Shoot -> LeftShift

Coke Player:
Mouse click the buttons on screen